package budgetcalculator;
import java.util.Scanner; 
import java.util.ArrayList;

public class BudgetCalculator {
    public static String expenseMessage(double income, String expense){
        return String.format("Your monthly expense for %s should be: $%.2f\n",expense, income);
    }
    
    public static String presetCalculation(double income){
        String presetResults = "";
        presetResults += String.format("Your monthly housing expense should be: $%.2f\n", (income * 0.3));
        presetResults += String.format("Your monthly grocery/food expense should be: $%.2f\n", (income * 0.1));
        presetResults += String.format("Your monthly Utilities expense should be: $%.2f\n", (income * 0.1));
        presetResults += String.format("Your monthly transportation expense should be: $%.2f\n", (income * 0.05));
        presetResults += String.format("Your monthly insurance expense should be: $%.2f\n", (income * 0.15));
        presetResults += String.format("Your monthly emergencies expense should be: $%.2f\n", (income * 0.05));
        presetResults += String.format("Your monthly savings expense should be: $%.2f\n", (income * 0.1));
        presetResults += String.format("Your monthly subscription services expense should be: $%.2f\n", (income * 0.05));
        presetResults += String.format("This will leave you with $%.2f to spend how you please." , (income * 0.1));
        return presetResults;
    }
    
    public static void customCalculation(double income){
        ArrayList<String> customexpense = new ArrayList<String>();
        ArrayList<Integer> customamount = new ArrayList<Integer>();
        int total = 0;
        int choice = 0;
    
        int grocerycost = 0;
        int utilitycost = 0;
        int transportationcost = 0;
        int insurancecost = 0;
        int emergencycost = 0;
        int savingscost = 0;
        int subscriptionscost = 0;
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the percent(as an integer) you would like to allocate toward each expense.\nif you do not pay for one of the expenses you may skip by entering 0. Custom expenses may be added at the end if you have not yet reached 100% of total income.");
        System.out.println("Enter how much you would like to allocate toward housing. %%100 of monthly income available: $%.2f(EX: 10% = 0.1)");
        int housingcost = scanner.nextInt();
        total += housingcost;
        
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward groceries/food. (EX: 10 = 10%)");
            grocerycost = scanner.nextInt();
            total += grocerycost;
        }
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward utilities. (EX: 10 = 10%)");
            utilitycost = scanner.nextInt();
            total += utilitycost;
        }
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward transportation. (EX: 10 = 10%)");
            transportationcost = scanner.nextInt();
            total += transportationcost;
        }
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward insurance. (EX: 10 = 10%)");
            insurancecost = scanner.nextInt();
            total += insurancecost;
        }
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward emergencies. (EX: 10 = 10%)");
            emergencycost = scanner.nextInt();
            total += emergencycost;
        }
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward savings. (EX: 10 = 10%)");
            savingscost = scanner.nextInt();
            total += savingscost;
        }    
        if(total < 100){
            System.out.println("Enter how much you would like to allocate toward subscription services. (EX: 10 = 10%)");
            subscriptionscost = scanner.nextInt();
            total += subscriptionscost;
            
        }
        if(total == 100){
            System.out.println("Warning: Total is 100%. You will not be able to create custom expenses.");
            System.out.println("Here are your total expenses: ");
            expenseMessage((housingcost/100.0)*income, "housing");
            expenseMessage((grocerycost/100.0)*income, "grocery");
            expenseMessage((utilitycost/100.0)*income, "utility");
            expenseMessage((transportationcost/100.0)*income, "transportation");
            expenseMessage((insurancecost/100.0)*income, "insurance");
            expenseMessage((emergencycost/100.0)*income, "emergency");
            expenseMessage((savingscost/100.0)*income, "savings");
            expenseMessage((subscriptionscost/100.0)*income, "subscriptions");
        }
        
        if(total > 100){
            System.out.println("Warning: Total exceeds 100%. The expenses will add up to more than your monthly income. The rest of the expense categories will be left unaccounted for.");
            System.out.println("Here are your total expenses: ");
            expenseMessage((housingcost/100.0)*income, "housing");
            expenseMessage((grocerycost/100.0)*income, "grocery");
            expenseMessage((utilitycost/100.0)*income, "utility");
            expenseMessage((transportationcost/100.0)*income, "transportation");
            expenseMessage((insurancecost/100.0)*income, "insurance");
            expenseMessage((emergencycost/100.0)*income, "emergency");
            expenseMessage((savingscost/100.0)*income, "savings");
            expenseMessage((subscriptionscost/100.0)*income, "subscriptions");
        }
        
        while(total < 100){
            System.out.println("Since you have not allocated all 100% of your income, you can now add a custom expense, leave the rest as spending money, or you can leave the rest in your savings.");
            System.out.println("Your remaining amount of money is: $" + ((100 - total)/100.0)*income);
            System.out.println("Select 1 if you would like to create a 'new expense'. \nSelect 2 if you would like to keep the rest of the money as 'spending money'. \nSelect 3 if you would like to add the rest of the money to savings.");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch(choice){
                case 1: 
                    System.out.println("Please enter a name for the new expense.");
                    customexpense.add(scanner.nextLine());
                    System.out.println("Enter how much you would like to allocate toward your new expense. (EX: 10 = 10%");
                    int newexpense = scanner.nextInt();
                    customamount.add(newexpense);
                    if(total + newexpense > 100){
                        
                        System.out.println("You have gone over the total amount of your income, please start over.");
                        customexpense.remove(customexpense.size() - 1);
                        customamount.remove(customexpense.size() - 1);
                        break;
                    }else if(total + newexpense < 100){
                        total += newexpense;
                    }else{
                        total += newexpense;
                        System.out.println("Here are your total expenses: ");
                        expenseMessage((housingcost/100.0)*income, "housing");
                        expenseMessage((grocerycost/100.0)*income, "grocery");
                        expenseMessage((utilitycost/100.0)*income, "utility");
                        expenseMessage((transportationcost/100.0)*income, "transportation");
                        expenseMessage((insurancecost/100.0)*income, "insurance");
                        expenseMessage((emergencycost/100.0)*income, "emergency");
                        expenseMessage((savingscost/100.0)*income, "savings");
                        expenseMessage((subscriptionscost/100.0)*income, "subscriptions");
                        for(int i = 0; i < customexpense.size(); i++){ //
                            expenseMessage((customamount.get(i)/100.0)*income, customexpense.get(i));
                        }
                    }
                    break;
                    
                case 2:
                    double spendingmoney = ((100 - total)/100.0)*income;
                    System.out.println("Here are your total expenses: ");
                    expenseMessage((housingcost/100.0)*income, "housing");
                    expenseMessage((grocerycost/100.0)*income, "grocery");
                    expenseMessage((utilitycost/100.0)*income, "utility");
                    expenseMessage((transportationcost/100.0)*income, "transportation");
                    expenseMessage((insurancecost/100.0)*income, "insurance");
                    expenseMessage((emergencycost/100.0)*income, "emergency");
                    expenseMessage((savingscost/100.0)*income, "savings");
                    expenseMessage((subscriptionscost/100.0)*income, "subscriptions");
                    System.out.println("And you have $" + spendingmoney + "left for spending.");
                    total=100;
                    break;
                    
                
                case 3: 
                    double savingscosts = savingscost*100 + ((100 - total)/100.0)*income;
                    System.out.println("Here are your total expenses: ");
                    expenseMessage((housingcost/100.0)*income, "housing");
                    expenseMessage((grocerycost/100.0)*income, "grocery");
                    expenseMessage((utilitycost/100.0)*income, "utility");
                    expenseMessage((transportationcost/100.0)*income, "transportation");
                    expenseMessage((insurancecost/100.0)*income, "insurance");
                    expenseMessage((emergencycost/100.0)*income, "emergency");
                    expenseMessage(savingscosts, "savings");
                    expenseMessage((subscriptionscost/100.0)*income, "subscriptions");
                    total=100;
                    break;    
                    
            }
        }   
    }
    public static void main(String[] args) {
        System.out.println("Enter your monthly income: ");
        Scanner scanner = new Scanner(System.in);
        double income = scanner.nextDouble();
        System.out.println("Select 1 if you would like to use a preset budget plan, or select 2 if you would like a custom budget plan.");
        int choice = scanner.nextInt();
        if(choice == 1){
            presetCalculation(income);
        }else if(choice == 2){
            customCalculation(income);
        }else{
            System.out.println("Error: Please input 1 or 2.");
        }
    }
}
